#include <bits/stdc++.h>
using namespace std;
int main (){
    ifstream cin ("KT.INP");
    ofstream cout ("KT.OUT");
int n,a[100];
cin >>n;
for (int i=0;i<n;i++){
    cin >> a[i];
}
for (int i =;i<n;i++){
    if (a[i]<a[i+1])
}
return 0;
}
