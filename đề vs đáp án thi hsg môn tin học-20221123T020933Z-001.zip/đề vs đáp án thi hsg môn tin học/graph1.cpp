#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int main(){
long long i,j,n,a[1000][1000],b[1000];
 ifstream cin("GRAPH.INP");
    ofstream cout("GRAPH.OUT");
//cin >>n;
/*for (i=1;i<=n;i++){
    for (j =1;j<=n;j++){
        cin >> a[i][j];
    }
}
for ( i=1;i<=n;i++){
    for (j =1;j<=n;j++){
            cout <<a[i][j]<<" ";
    }}*/
    cout <<"hhhhhh";
/*for (i=1;i<=n;i++){
    for (j =1;j<=n;j++){
        b[i]+=a[i][j];
    }
}
for (i=1;i<=n;i++){
    cout <<b[i]<<" ";
}*/
return 0;
}
